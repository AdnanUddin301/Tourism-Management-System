<footer>
    <style>
        footer {
            text-align: center;
            background-color: #f4f4f4; /* Optional: Adds a light background color */
            padding: 20px; /* Adds some spacing around the footer */
            margin-top: 20px;
            box-shadow: 0 -2px 6px rgba(0, 0, 0, 0.1);
        }

        footer .about {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        footer .about .social-icons {
            display: flex; /* Align items in a single row */
            justify-content: center; /* Center items horizontally */
            gap: 10px; /* Space between icons */
            margin-top: 10px; /* Adds space above icons */
        }

        footer img {
            vertical-align: middle; /* Ensures icons align properly */
        }

        footer p {
            margin: 10px 0 0;
            font-size: 14px; /* Adjust text size */
        }
    </style>
    
    <div class="about">
        <h2>About Us</h2>
        <div class="social-icons">
            <a href="https://www.facebook.com/"> 
                <img src="assets\images\facebook.png" height="25px" width="25px"> 
            </a>
            <a href="https://www.instagram.com/"> 
                <img src="assets\images\instagram.png" height="25px" width="25px"> 
            </a>
            <a href="https://twitter.com/"> 
                <img src="assets\images\twitter.png" height="25px" width="25px"> 
            </a>
        </div>
        <p>
            <b>Posted by: Adnan Uddin<br>
            <br>
            Contact Agencies: niloyagencies@gmail.com<br>
            </b>
        </p>
    </div>
    <p>&copy; <?php echo date("Y"); ?></p>
</footer>
