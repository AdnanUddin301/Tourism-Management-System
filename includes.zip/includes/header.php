<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tourism Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.14/dist/full.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<nav class="navbar bg-blue-700 text-white shadow-lg">
    <div class="navbar-start">
        <div class="dropdown">
            <button tabindex="0" class="btn btn-ghost lg:hidden">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h8m-8 6h16" />
                </svg>
            </button>
            <ul tabindex="0" class="menu menu-sm dropdown-content bg-white rounded-box z-[1] mt-3 w-52 p-2 shadow-lg">
                <li><a href="home.php" class="text-gray-700 hover:text-blue-700">Home</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="tourist_spots.php" class="text-gray-700 hover:text-blue-700">Tourist Spots</a></li>
                    <li><a href="logout.php" class="text-gray-700 hover:text-blue-700">Logout</a></li>
                <?php else: ?>
                    <li><a href="signin.php" class="text-gray-700 hover:text-blue-700">Sign In</a></li>
                    <li><a href="signup.php" class="text-gray-700 hover:text-blue-700">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
        <a href="#" class="btn btn-ghost normal-case text-xl">Tourism System</a>
    </div>

    <div class="navbar-center hidden lg:flex">
        <ul class="menu menu-horizontal px-1">
            <li><a href="home.php" class="hover:text-blue-400">Home</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="catagories.php" class="hover:text-blue-400">catagory</a></li>
                <li><a href="logout.php" class="hover:text-blue-400">Logout</a></li>
            <?php else: ?>
                <li><a href="signin.php" class="hover:text-blue-400">Sign In</a></li>
                <li><a href="signup.php" class="hover:text-blue-400">Sign Up</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="navbar-end">
        <a href="https://www.facebook.com/" class="btn bg-blue-500 hover:bg-blue-600 text-white">Contact Us</a>
    </div>
</nav>

<!-- Removed Hero Section -->
</body>
</html>

